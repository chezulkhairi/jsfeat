A Pen created at CodePen.io. You can find this one at https://codepen.io/chezulkhairi/pen/OaQRva.

 A demo I will present in a local meetup. It uses JSFeat to detect the feature points and use delaunay to create the triangle geometry. This demo is using canvas as renderer, and I didn't fully optimize it. WebGL version will be coming soon with some fake 3D enhancement. *You can also drag and drop your images and exports it as PNG or SVG.

Forked from [Edan Kwan](http://codepen.io/edankwan/)'s Pen [Delaunay + JSFeat Canvas Demo](http://codepen.io/edankwan/pen/RNzBgR/).